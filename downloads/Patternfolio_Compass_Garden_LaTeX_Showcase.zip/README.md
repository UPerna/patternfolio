# Compass Garden LaTeX showcase

Compile the example from this folder with either command.

```sh
lualatex -halt-on-error compass-garden.tex
xelatex -halt-on-error compass-garden.tex
```

The source uses `geometry`, `graphicx` and `xcolor`. It places the included
vector PDF with `\includegraphics`. A Patternfolio installation is needed only
if you want to regenerate the ornament.

- `compass-garden.tex` is the editable chapter opener.
- `compass-band.pdf` is the decorated Penrose band from the Pattern Atlas built at
  `8cdfdb52dfe84ac94a94058ed2dacd947ed559c8`.
- `Compass_Garden_Showcase.pdf` is the compiled page. The PNG is ready to share.

[Try Patternfolio](https://uperna.github.io/patternfolio/) ·
[Compass Garden recipes and construction](https://github.com/UPerna/patternfolio/blob/8cdfdb52dfe84ac94a94058ed2dacd947ed559c8/docs/design/ORIGINAL-COLLECTIONS.md) ·
[Original Florilegium project by Kevin Raymond](https://github.com/kevinraymond/florilegium)
